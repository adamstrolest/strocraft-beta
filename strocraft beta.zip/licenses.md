any models are protected under Creative Commons licenses
"Minecraft Sheep" (https://skfb.ly/oxrH7) by Mr. Snark is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).


"Rudolph the red nosed wolf/dog - minecraft wolf" (https://skfb.ly/onGDQ) by Evil_Katz is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).