# minecraft_game.py (version française) - Modèles Ursina modifié

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import subprocess
import sys
import os
import json
import math
import random
import time
import threading

# --- Tentative d'importation d'ursina et de ses dépendances ---
try:
    from ursina import *
    from ursina.prefabs.first_person_controller import FirstPersonController
    from ursina.shaders import lit_with_shadows_shader
except ImportError:
    print("ATTENTION : La bibliothèque 'ursina' n'est pas installée. Le jeu ne sera pas jouable.")
    print("Veuillez l'installer en utilisant : pip install ursina")

# --- Variables de configuration globales ---
game_action = "new"
game_load_path = None
app = None
world_entities = []

# --- Fonctions du menu ---
def run_game():
    """Lance le jeu Ursina en fonction des paramètres globaux."""
    global app, world_entities

    try:
        if 'ursina' not in sys.modules:
            messagebox.showerror("Erreur de lancement", "La bibliothèque 'ursina' n'est pas installée. Le jeu ne peut pas être lancé.")
            return

        app = Ursina()
        setup_game()

    except Exception as e:
        messagebox.showerror("Erreur de lancement", f"Impossible de lancer le jeu : {e}")
        sys.exit(1)

def start_new_game():
    """Définit les paramètres pour une nouvelle partie et la lance."""
    global game_action
    game_action = "new"
    root.destroy()
    run_game()

def import_world():
    """Ouvre une boîte de dialogue pour choisir un monde et lance le jeu."""
    global game_action, game_load_path
    file_path = filedialog.askopenfilename(
        initialdir=".",
        title="Sélectionner un fichier de monde .scw",
        filetypes=(("Fichiers Stro Craft World", "*.scw"), ("Tous les fichiers", "*.*"))
    )
    if file_path:
        game_action = "load"
        game_load_path = file_path
        root.destroy()
        run_game()
    else:
        messagebox.showinfo("Annulé", "Aucun fichier sélectionné. Le jeu ne sera pas lancé.")

def show_help():
    """Affiche une boîte de dialogue d'aide."""
    help_text = (
        "Commandes du jeu :\n\n"
        "Clic gauche : Placer un bloc\n"
        "Clic droit : Détruire un bloc\n"
        "WASD : Se déplacer\n"
        "Espace : Sauter\n"
        "Tab : Changer de bloc\n"
        "1-0 : Sélection rapide des blocs\n"
        "F : Sauvegarder le monde\n"
        "L : Sauvegarder sous un autre nom\n"
        "T : Avancer le temps (pour test)\n"
        "E : Interagir (portes, lits, TNT)\n"
        "ESC : Quitter le jeu\n\n"
        "Nouveautés :\n"
        "- Chiens domestiques qui vous suivent\n"
        "- Poulets plus réalistes\n"
        "- Inventaire automatique en arrière-plan"
    )
    messagebox.showinfo("Aide", help_text)

def show_settings():
    """Affiche une boîte de dialogue des paramètres."""
    settings_text = "À propos du jeu :\n- Créé par arabic progmaster\n- Le moteur de jeu est ursina engine\n- Ce programme a été créé en utilisant Python avec l'aide de claude.ai, google gemini et deep ai\n\nNouvelles fonctionnalités :\n- Chiens domestiques\n- Animaux améliorés\n- Système d'inventaire simplifié"
    messagebox.showinfo("À propos du jeu", settings_text)

# --- Constantes pour les couleurs de la console ---
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
BLACK = "\033[30m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"
BG_BLACK = "\033[40m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"
BG_MAGENTA = "\033[45m"
BG_CYAN = "\033[46m"
BG_WHITE = "\033[47m"
BG_LIGHTBLUE = "\033[104m"

# --- Variables d'état du jeu ---
game_time = 0
day_duration = 150
player_inventory = {}

# --- Textures et outils ---
TEXTURES = {
    'grass': 'grass', 'stone': 'stone', 'brick': 'brick', 'dirt': 'dirt',
    'glass': 'glass.png', 'door_tool': 'door_tool_id', 'door_texture': 'door_texture.png',
    'blue_cube': 'bl.png', 'red_cube': 'red.png', 'yellow_cube': 'sun.png',
    'black_cube': 'bla.png', 'bed_tool': 'bed_tool_id', 'bed_texture': 'bed_texture.png',
    'tnt_tool': 'tnt_tool_id', 'tnt_texture': 'tnt_texture.png',
    'sheep_texture': 'sheep.png', 'chicken_texture': 'chicken.png',
    'blockyman_body': 'brick', 'blockyman_head': 'dirt',
    'house_door_sensor_texture': 'invisible_block.png', 'bedrock': 'bedrock.png',
    'wood': 'wood.png', 
    'white_bloc': 'white_cube', 'wool': 'white_cube', 'tree_trunk': 'wood.png',
    'leaves': 'grass'
}

TEXTURE_LIST = [
    ('grass', 'Herbe'), ('dirt', 'Terre'), ('bedrock', 'Bedrock'),
    ('stone', 'Pierre'), ('brick', 'Brique'), ('wood', 'Bois'),
    ('glass', 'Verre'), ('blue_cube', 'Cube bleu'),
    ('red_cube', 'Cube rouge'), ('yellow_cube', 'Cube jaune'),
    ('black_cube', 'Cube noir'), ('white_bloc', 'Laine')
]

current_texture_index = 0
current_texture = TEXTURES[TEXTURE_LIST[current_texture_index][0]]
current_door_rotation = 0
current_bed_rotation = 0
player = None
sleep_fade_overlay = None
ambient_light = None

# --- Classes de jeu ---
class Block(Button):
    def __init__(self, position=(0, 0, 0), texture=TEXTURES['grass']):
        super().__init__(
            parent=scene, position=position, model='cube', origin_y=0.5,
            texture=texture, color=color.white, highlight_color=color.lime,
            collider='box'
        )
        self.block_texture_name = None
        for name, value in TEXTURES.items():
            if value == texture:
                self.block_texture_name = name
                break
        if self.block_texture_name is None and isinstance(texture, str):
            self.block_texture_name = texture

    def input(self, key):
        if self.hovered:
            if key == 'left mouse down':
                new_object_pos = self.position + mouse.normal
                if current_texture == TEXTURES['door_tool']:
                    new_door = Door(position=new_object_pos, rotation_y=current_door_rotation)
                    world_entities.append(new_door)
                elif current_texture == TEXTURES['bed_tool']:
                    new_bed = Bed(position=new_object_pos, rotation_y=current_bed_rotation)
                    world_entities.append(new_bed)
                elif current_texture == TEXTURES['tnt_tool']:
                    new_tnt = TNTBlock(position=new_object_pos)
                    world_entities.append(new_tnt)
                else:
                    new_block = Block(position=new_object_pos, texture=current_texture)
                    world_entities.append(new_block)
                return

            if key == 'right mouse down':
                if self.block_texture_name in ['house_door_sensor', 'bedrock']:
                    print(f"{YELLOW}Impossible de détruire ce bloc !{RESET}")
                    return
                
                # Ajouter le bloc détruit à l'inventaire (en arrière-plan)
                add_to_inventory(self.block_texture_name, 1)
                
                if self in world_entities:
                    world_entities.remove(self)
                destroy(self)
                return

class Tree(Entity):
    def __init__(self, position=(0, 0, 0)):
        super().__init__(parent=scene, position=position)
        
        # Tronc
        self.trunk = Block(position=(position[0], position[1] + 1, position[2]), 
                          texture=TEXTURES['tree_trunk'])
        self.trunk.block_texture_name = 'wood'
        world_entities.append(self.trunk)
        
        self.trunk2 = Block(position=(position[0], position[1] + 2, position[2]), 
                           texture=TEXTURES['tree_trunk'])
        self.trunk2.block_texture_name = 'wood'
        world_entities.append(self.trunk2)
        
        self.trunk3 = Block(position=(position[0], position[1] + 3, position[2]), 
                           texture=TEXTURES['tree_trunk'])
        self.trunk3.block_texture_name = 'wood'
        world_entities.append(self.trunk3)
        
        # Feuilles
        for y in range(4, 6):
            for x in range(-2, 3):
                for z in range(-2, 3):
                    if abs(x) + abs(z) < 4:
                        leaves = Block(position=(position[0] + x, position[1] + y, position[2] + z),
                                     texture=TEXTURES['leaves'])
                        leaves.block_texture_name = 'leaves'
                        world_entities.append(leaves)

class Door(Entity):
    def __init__(self, position=(0, 0, 0), rotation_y=0, scale=(1, 2.5, 0.1), texture=TEXTURES['door_texture']):
        super().__init__(
            parent=scene, position=position, model='cube', scale=scale, origin_y=-0.5,
            texture=texture, color=color.white, collider='box', rotation_y=rotation_y
        )
        self.is_open = False
        self.original_rotation_y = self.rotation_y
        self.door_texture_name = TEXTURES['door_texture']
        self.occupied = False

    def open_door(self):
        if not self.is_open:
            self.animate_rotation_y(self.original_rotation_y + 90, duration=0.5)
            self.is_open = True
            print(f"{YELLOW}La porte est ouverte !{RESET}")

    def close_door(self):
        if self.is_open:
            self.animate_rotation_y(self.original_rotation_y, duration=0.5)
            self.is_open = False
            print(f"{YELLOW}La porte est fermée !{RESET}")

    def toggle_door(self):
        if self.is_open:
            self.close_door()
        else:
            self.open_door()

class Bed(Entity):
    def __init__(self, position=(0, 0, 0), rotation_y=0, texture=TEXTURES['bed_texture']):
        super().__init__(
            parent=scene, position=position, model='cube', scale=(1, 0.5, 2),
            origin_y=-0.5, texture=texture, color=color.white, collider='box',
            rotation_y=rotation_y
        )
        self.bed_texture_name = TEXTURES['bed_texture']
        self.occupied = False
        self.occupant = None

    def interact(self):
        global game_time, sleep_fade_overlay
        if is_night():
            print(f"{YELLOW}Vous dormez... Zzz...{RESET}")
            player.disable()
            sleep_fade_overlay.fade_in(duration=2.0)
            invoke(self.wake_up_in_morning, delay=5)
        else:
            print(f"{YELLOW}Vous ne pouvez dormir que la nuit.{RESET}")

    def wake_up_in_morning(self):
        global game_time, sleep_fade_overlay
        game_time = int(game_time) + 2
        print(f"{YELLOW}Vous vous réveillez, c'est le matin !{RESET}")
        player.enable()
        sleep_fade_overlay.fade_out(duration=2.0)

    def occupy(self, blockyman):
        if not self.occupied:
            self.occupied = True
            self.occupant = blockyman
            return True
        return False

    def free(self):
        self.occupied = False
        self.occupant = None

class TNTBlock(Block):
    def __init__(self, position=(0, 0, 0)):
        super().__init__(position=position, texture=TEXTURES['tnt_texture'])
        self.block_texture_name = 'tnt_texture'
        self.is_exploding = False
        self.primed = False

    def prime(self, delay=5):
        if self.primed:
            print(f"{DIM}TNT à {self.position} est déjà amorcé. Commande ignorée.{RESET}")
            return
        self.primed = True
        print(f"{YELLOW}TNT à {self.position} est amorcé ! Explosion dans {delay} secondes...{RESET}")
        invoke(self.explode, delay=delay)

    def explode(self, radius=3):
        if self.is_exploding or not self.enabled:
            return
        self.is_exploding = True
        print(f"{RED}{BOLD}TNT à {self.position} explose !{RESET}")
        tnt_x, tnt_y, tnt_z = self.x, self.y, self.z
        if self in world_entities:
            world_entities.remove(self)
        invoke(destroy, self, delay=0.01)
        entities_snapshot = list(world_entities)
        blocks_to_destroy_in_explosion = []
        for entity in entities_snapshot:
            try:
                if not entity.enabled:
                    continue
                if isinstance(entity, Block):
                    dist = math.sqrt(
                        (entity.x - tnt_x)**2 + (entity.y - tnt_y)**2 + (entity.z - tnt_z)**2
                    )
                    if dist <= radius and entity.block_texture_name != 'bedrock':
                        blocks_to_destroy_in_explosion.append(entity)
            except Exception:
                continue
        for block in blocks_to_destroy_in_explosion:
            try:
                if block.enabled:
                    if block in world_entities:
                        world_entities.remove(block)
                    invoke(destroy, block, delay=0.01)
            except Exception:
                continue   
        flash = Entity(model='sphere', color=color.orange, scale=radius * 0.5,
                       position=(tnt_x, tnt_y, tnt_z), shader=lit_with_shadows_shader, texture='white_cube')
        flash.fade_out(duration=0.5, delay=0, curve=curve.linear)
        invoke(lambda: destroy(flash), delay=0.6)

# --- Système d'inventaire simplifié (arrière-plan) ---
def add_to_inventory(item, quantity):
    if item in player_inventory:
        player_inventory[item] += quantity
    else:
        player_inventory[item] = quantity
    print(f"{GREEN}+{quantity} {item} ajouté à l'inventaire (total: {player_inventory[item]}){RESET}")

def remove_from_inventory(item, quantity):
    if item in player_inventory and player_inventory[item] >= quantity:
        player_inventory[item] -= quantity
        if player_inventory[item] == 0:
            del player_inventory[item]
        return True
    return False

# --- Classe de base pour les mobs ---
class Mob(Entity):
    def __init__(self, position=(0,0,0), speed=1, health=10, **kwargs):
        super().__init__(
            parent=scene, position=position, collider='box', origin_y=-0.5, **kwargs
        )
        self.speed = speed
        self.health = health
        self.max_health = health
        self.target_position = None
        self.path = []
        self.is_moving = False

    def move_to(self, target_pos):
        self.target_position = Vec3(target_pos)
        self.is_moving = True

    def update(self):
        if self.is_moving and self.target_position:
            if not isinstance(self.target_position, Vec3):
                self.target_position = Vec3(self.target_position)
            direction = (self.target_position - self.position).normalized()
            self.position += direction * self.speed * time.dt
            if distance(self.position, self.target_position) < 0.1:
                self.is_moving = False
                self.target_position = None
                self.on_target_reached()

    def on_target_reached(self):
        pass

    def take_damage(self, amount):
        self.health -= amount
        print(f"{RED}{self.__class__.__name__} a subi {amount} de dégâts ! Santé : {self.health}/{self.max_health}{RESET}")
        if self.health <= 0:
            self.die()

    def die(self):
        print(f"{RED}{self.__class__.__name__} est mort !{RESET}")
        if self in world_entities:
            world_entities.remove(self)
        destroy(self)

# --- Classes des animaux avec modèles Ursina ---
class Dog(Entity):
    def __init__(self, position=(0, 0, 0)):
        super().__init__(
            parent=scene,
            position=position,
            scale=0.6,  # Ajustez la taille du modèle selon vos besoins
            model='wolf (2).gltf',  # Le fichier du modèle GLTF
            texture='gltf_embedded_0.png',  # Le fichier de la texture
            collider='box'
        )
        
        # Variables pour le comportement du chien (à ajouter si nécessaire)
        # self.follow_distance = 5.0
        # self.is_following_player = True
        # ...
        
    def update(self):
        # Mettez ici le comportement du chien si vous le souhaitez
        # Par exemple, pour le faire se déplacer
        # super().update()
        pass

class Chicken(Mob):
    def __init__(self, position=(0, 0, 0)):
        # Corps principal
        super().__init__(
            position=position, model='cube', scale=(0.6, 0.8, 1.0), 
            health=3, speed=0.8, color=color.rgb(255, 255, 200)
        )
        
        # Tête
        self.head = Entity(
            parent=self, model='cube', scale=(0.4, 0.4, 0.4),
            position=(0, 0.6, 0.5), color=color.rgb(255, 255, 200)
        )
        
        # Bec
        self.beak = Entity(
            parent=self.head, model='cube', scale=(0.15, 0.1, 0.2),
            position=(0, 0, 0.25), color=color.orange
        )
        
        # Yeux
        self.left_eye = Entity(
            parent=self.head, model='cube', scale=(0.08, 0.08, 0.08),
            position=(-0.12, 0.05, 0.15), color=color.black
        )
        self.right_eye = Entity(
            parent=self.head, model='cube', scale=(0.08, 0.08, 0.08),
            position=(0.12, 0.05, 0.15), color=color.black
        )
        
        # Crête
        self.comb = Entity(
            parent=self.head, model='cube', scale=(0.2, 0.3, 0.1),
            position=(0, 0.25, 0), color=color.red
        )
        
        # Ailes
        self.left_wing = Entity(
            parent=self, model='cube', scale=(0.1, 0.6, 0.8),
            position=(-0.35, 0, 0), color=color.rgb(200, 200, 150)
        )
        self.right_wing = Entity(
            parent=self, model='cube', scale=(0.1, 0.6, 0.8),
            position=(0.35, 0, 0), color=color.rgb(200, 200, 150)
        )
        
        # Pattes
        self.left_leg = Entity(
            parent=self, model='cube', scale=(0.15, 0.5, 0.15),
            position=(-0.2, -0.65, 0), color=color.orange
        )
        self.right_leg = Entity(
            parent=self, model='cube', scale=(0.15, 0.5, 0.15),
            position=(0.2, -0.65, 0), color=color.orange
        )
        
        # Queue
        self.tail = Entity(
            parent=self, model='cube', scale=(0.3, 0.5, 0.1),
            position=(0, 0.2, -0.5), color=color.rgb(180, 180, 120)
        )
        
        # Variables pour l'animation et le comportement
        self.random_walk_cooldown = 0
        self.walk_animation_time = 0
        self.wing_flap_time = 0
        self.peck_time = 0

    def update(self):
        super().update()
        
        # Animation de marche
        if self.is_moving:
            self.walk_animation_time += time.dt * 8
            leg_swing = math.sin(self.walk_animation_time) * 20
            self.left_leg.rotation_x = leg_swing
            self.right_leg.rotation_x = -leg_swing
            
            head_bob = math.sin(self.walk_animation_time * 2) * 10
            self.head.rotation_x = head_bob
        else:
            self.left_leg.rotation_x = 0
            self.right_leg.rotation_x = 0
            self.head.rotation_x = 0
            
            # Animation de "picorage" quand immobile
            self.peck_time += time.dt
            if self.peck_time > 2:  # Picore toutes les 2 secondes
                peck_animation = math.sin(time.time() * 10) * 30
                self.head.rotation_x = peck_animation
                if self.peck_time > 2.5:
                    self.peck_time = 0
        
        # Animation des ailes
        self.wing_flap_time += time.dt
        wing_flap = math.sin(self.wing_flap_time * 3) * 15
        self.left_wing.rotation_z = wing_flap
        self.right_wing.rotation_z = -wing_flap
        
        # Déplacement aléatoire
        if not self.is_moving:
            self.random_walk_cooldown -= time.dt
            if self.random_walk_cooldown <= 0:
                self.start_random_walk()

    def start_random_walk(self):
        random_x = self.x + random.uniform(-4, 4)
        random_z = self.z + random.uniform(-4, 4)
        random_x = max(0, min(34, random_x))
        random_z = max(0, min(34, random_z))
        self.move_to((random_x, self.y, random_z))
        self.random_walk_cooldown = random.uniform(1, 4)

    def on_target_reached(self):
        self.is_moving = False
        self.random_walk_cooldown = random.uniform(0.5, 3)
        
    def die(self):
        print(f"{RED}Le poulet est mort !{RESET}")
        add_to_inventory('white_bloc', random.randint(0, 2))
        # Détruire tous les composants
        components = [self.head, self.beak, self.left_eye, self.right_eye, self.comb,
                     self.left_wing, self.right_wing, self.left_leg, self.right_leg, self.tail]
        for component in components:
            if component:
                destroy(component)
        super().die()

class Sheep(Mob):
    def __init__(self, position=(0,0,-1)):
        super().__init__(
            position=position, 
            model='sheep.gltf', # Remplacez par le nom de votre modèle 3D
            texture='gltf_embedded_1.png', # Remplacez par le nom de votre texture
            scale=1.0, # Ajustez la taille du modèle au besoin
            health=6, 
            speed=1.0
        )
        
        self.random_walk_cooldown = 0
        self.is_grazing = False
        
    def update(self):
        super().update()
        
        self.random_walk_cooldown -= time.dt
        
        if self.random_walk_cooldown <= 0:
            self.start_random_walk()
            
    def start_random_walk(self):
        random_x = random.uniform(self.x - 5, self.x + 5)
        random_z = random.uniform(self.z - 5, self.z +6)
        self.move_to((random_x, self.y, random_z))
        self.random_walk_cooldown = random.uniform(5, 15)

    def on_target_reached(self):
        self.random_walk_cooldown = 0
        self.is_moving = False

class Blockyman(Entity):
    def __init__(self, position=(0,0,0)):
        super().__init__(
            parent=scene, position=position, model='cube', texture=TEXTURES['blockyman_body'],
            scale=(0.8, 1.6, 0.8), color=color.rgb(139, 69, 19), collider='box', origin_y=-0.5
        )
        self.head = Entity(parent=self, model='cube', texture=TEXTURES['blockyman_head'],
                           scale=(1, 0.8, 1), position=(0, 1.2, 0), color=color.rgb(245, 222, 179))
        self.left_eye = Entity(parent=self.head, model='cube', scale=(0.15, 0.15, 0.1),
                               position=(-0.2, 0.1, 0.45), color=color.black)
        self.right_eye = Entity(parent=self.head, model='cube', scale=(0.15, 0.15, 0.1),
                                position=(0.2, 0.1, 0.45), color=color.black)
        self.left_hand = Entity(parent=self, model='cube', texture=TEXTURES['blockyman_head'],
                                scale=(0.3, 0.3, 0.8), position=(-0.6, 0.8, 0),
                                color=color.rgb(245, 222, 179))
        self.right_hand = Entity(parent=self, model='cube', texture=TEXTURES['blockyman_head'],
                                 scale=(0.3, 0.3, 0.8), position=(0.6, 0.8, 0),
                                 color=color.rgb(245, 222, 179))
        self.speed = 0.8
        self.health = 15
        self.status = "wandering"
        self.target_position = None
        self.is_moving = False
        self.wander_radius = 15
        self.current_bed = None
        self.sleep_timer = 0
        self.wander_cooldown = 0
        self.last_bed_search = 0

    def update(self):
        global game_time
        if self.wander_cooldown > 0:
            self.wander_cooldown -= time.dt
        self.animate_hands()
        if is_night() and self.status != "sleeping":
            if self.status != "seeking_bed":
                print(f"{CYAN}Blockyman : C'est la nuit, je cherche un lit !{RESET}")
                self.status = "seeking_bed"
            self.seek_bed()
        elif not is_night() and self.status == "sleeping":
            self.wake_up()
        elif not is_night() and self.status != "wandering":
            self.status = "wandering"
        if self.is_moving and self.target_position:
            direction = (self.target_position - self.position).normalized()
            self.position += direction * self.speed * time.dt
            if distance(self.position, self.target_position) < 0.5:
                self.on_target_reached()
        elif self.status == "wandering" and not self.is_moving and self.wander_cooldown <= 0:
            self.start_random_walk()

    def animate_hands(self):
        if self.is_moving:
            swing = math.sin(time.time() * 8) * 30
            self.left_hand.rotation_x = swing
            self.right_hand.rotation_x = -swing
        else:
            swing = math.sin(time.time() * 2) * 10
            self.left_hand.rotation_x = swing
            self.right_hand.rotation_x = -swing

    def move_to(self, target_pos):
        self.target_position = Vec3(target_pos)
        self.is_moving = True

    def start_random_walk(self):
        random_x = self.x + random.uniform(-self.wander_radius, self.wander_radius)
        random_z = self.z + random.uniform(-self.wander_radius, self.wander_radius)
        random_x = max(1, min(33, random_x))
        random_z = max(1, min(33, random_z))
        self.move_to((random_x, self.y, random_z))
        self.wander_cooldown = random.uniform(3, 8)

    def seek_bed(self):
        if time.time() - self.last_bed_search < 2:
            return
        self.last_bed_search = time.time()
        closest_bed = None
        min_distance = float('inf')
        for entity in world_entities:
            if isinstance(entity, Bed) and not entity.occupied:
                bed_distance = distance(self.position, entity.position)
                if bed_distance < min_distance:
                    min_distance = bed_distance
                    closest_bed = entity
        if closest_bed:
            print(f"{YELLOW}Blockyman : J'ai trouvé un lit à {closest_bed.position} !{RESET}")
            self.move_to(closest_bed.position)
            self.current_bed = closest_bed
        else:
            if not self.is_moving:
                self.start_random_walk()

    def on_target_reached(self):
        self.is_moving = False
        self.target_position = None
        if self.status == "seeking_bed" and self.current_bed:
            if not self.current_bed.occupied:
                self.sleep_in_bed(self.current_bed)
            else:
                print(f"{RED}Blockyman : Oh non ! Quelqu'un a pris mon lit !{RESET}")
                self.current_bed = None
                self.seek_bed()
        elif self.status == "wandering":
            self.wander_cooldown = random.uniform(2, 5)

    def sleep_in_bed(self, bed):
        if bed.occupy(self):
            self.status = "sleeping"
            self.current_bed = bed
            self.position = Vec3(bed.x, bed.y + 0.3, bed.z)
            self.animate_rotation_x(90, duration=1.0)
            print(f"{GREEN}Blockyman : Zzz... Bonne nuit ! *s'endort sur le lit*{RESET}")

    def wake_up(self):
        if self.current_bed:
            self.current_bed.free()
            self.current_bed = None
        self.animate_rotation_x(0, duration=1.0)
        self.status = "wandering"
        print(f"{YELLOW}Blockyman : *bâille* Bonjour ! C'est le jour !{RESET}")

    def die(self):
        print(f"{RED}Blockyman est mort !{RESET}")
        if self.current_bed:
            self.current_bed.free()
        if self in world_entities:
            world_entities.remove(self)
        destroy(self.head)
        destroy(self.left_eye)
        destroy(self.right_eye)
        destroy(self.left_hand)
        destroy(self.right_hand)
        destroy(self)

# --- Fonctions de sauvegarde/chargement du monde ---
def save_world(filename="my_world.scw"):
    world_data = []
    active_entities = [e for e in world_entities if e.enabled]
    for entity in active_entities:
        if isinstance(entity, Block):
            world_data.append({'type': 'block', 'position': [int(entity.x), int(entity.y), int(entity.z)],
                               'texture': entity.block_texture_name})
        elif isinstance(entity, Door):
            world_data.append({'type': 'door', 'position': [int(entity.x), int(entity.y), int(entity.z)],
                               'rotation_y': int(entity.original_rotation_y), 'texture': entity.door_texture_name})
        elif isinstance(entity, Bed):
            world_data.append({'type': 'bed', 'position': [int(entity.x), int(entity.y), int(entity.z)],
                               'rotation_y': int(entity.rotation_y), 'texture': entity.bed_texture_name,
                               'occupied': entity.occupied})
        elif isinstance(entity, TNTBlock):
            world_data.append({'type': 'tnt', 'position': [int(entity.x), int(entity.y), int(entity.z)],
                               'texture': entity.block_texture_name})
        elif isinstance(entity, Dog):
            world_data.append({'type': 'dog', 'position': [round(entity.x, 2), round(entity.y, 2), round(entity.z, 2)],
                               'health': entity.health})
        elif isinstance(entity, Sheep):
            world_data.append({'type': 'sheep', 'position': [round(entity.x, 2), round(entity.y, 2), round(entity.z, 2)],
                               'health': entity.health})
        elif isinstance(entity, Chicken):
            world_data.append({'type': 'chicken', 'position': [round(entity.x, 2), round(entity.y, 2), round(entity.z, 2)],
                               'health': entity.health})
        elif isinstance(entity, Blockyman):
            world_data.append({'type': 'blockyman', 'position': [round(entity.x, 2), round(entity.y, 2), round(entity.z, 2)],
                               'health': entity.health, 'status': entity.status})
    
    # Sauvegarder l'inventaire et l'état du jeu
    world_data.append({'type': 'game_state', 'game_time': game_time})
    world_data.append({'type': 'inventory', 'items': player_inventory})
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(world_data, f, indent=4, ensure_ascii=False)
        print(f"{YELLOW}Monde sauvegardé dans '{filename}'{RESET}")
    except Exception as e:
        print(f"{RED}Erreur lors de la sauvegarde du monde : {e}{RESET}")

def load_world(filename):
    global world_entities, game_time, player_inventory
    if not os.path.exists(filename):
        print(f"{RED}Le fichier '{filename}' n'existe pas. Impossible de charger le monde.{RESET}")
        if player:
            invoke(player.enable, delay=0.1)
        return
    entities_to_clear = list(world_entities)
    for entity in entities_to_clear:
        if entity.enabled:
            invoke(destroy, entity, delay=0.01)
    world_entities.clear()
    player_inventory.clear()
    print(f"{BG_LIGHTBLUE}{BLACK}Toutes les entités précédentes ont été détruites. Nombre d'entités après destruction : {len(world_entities)}{RESET}")
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            world_data = json.load(f)
        for item in world_data:
            entity_type = item.get('type')
            if entity_type == 'game_state':
                game_time = item.get('game_time', 0)
                continue
            elif entity_type == 'inventory':
                player_inventory.update(item.get('items', {}))
                continue
            
            position = tuple(item.get('position', (0,0,0)))
            texture_name = item.get('texture', 'grass')
            texture_value = TEXTURES.get(texture_name, texture_name)
            
            if entity_type == 'block':
                new_block = Block(position=position, texture=texture_value)
                world_entities.append(new_block)
            elif entity_type == 'door':
                rotation_y = item.get('rotation_y', 0)
                new_door = Door(position=position, rotation_y=rotation_y, texture=texture_value)
                world_entities.append(new_door)
            elif entity_type == 'bed':
                rotation_y = item.get('rotation_y', 0)
                occupied = item.get('occupied', False)
                new_bed = Bed(position=position, rotation_y=rotation_y, texture=texture_value)
                new_bed.occupied = occupied
                world_entities.append(new_bed)
            elif entity_type == 'tnt':
                new_tnt = TNTBlock(position=position)
                world_entities.append(new_tnt)
            elif entity_type == 'dog':
                health = item.get('health', 8)
                new_dog = Dog(position=position)
                new_dog.health = health
                world_entities.append(new_dog)
            elif entity_type == 'sheep':
                health = item.get('health', 5)
                new_sheep = Sheep(position=position)
                new_sheep.health = health
                world_entities.append(new_sheep)
            elif entity_type == 'chicken':
                health = item.get('health', 3)
                new_chicken = Chicken(position=position)
                new_chicken.health = health
                world_entities.append(new_chicken)
            elif entity_type == 'blockyman':
                health = item.get('health', 15)
                status = item.get('status', 'wandering')
                new_blockyman = Blockyman(position=position)
                new_blockyman.health = health
                new_blockyman.status = status
                world_entities.append(new_blockyman)
            elif entity_type == 'zombie' or entity_type == 'red_creeper':
                health = item.get('health', 15)
                new_blockyman = Blockyman(position=position)
                new_blockyman.health = health
                world_entities.append(new_blockyman)
                print(f"{YELLOW}L'ancien {entity_type} a été converti en Blockyman à {position}{RESET}")
        print(f"{YELLOW}Monde chargé depuis '{filename}'. Nombre d'entités chargées : {len(world_entities)}{RESET}")
        print(f"{CYAN}Inventaire chargé avec {len(player_inventory)} types d'objets{RESET}")
        if player:
            invoke(player.enable, delay=0.1)
    except json.JSONDecodeError:
        print(f"{RED}Erreur : Le fichier '{filename}' n'est pas un fichier JSON valide.{RESET}")
        if player:
            invoke(player.enable, delay=0.1)
    except Exception as e:
        print(f"{RED}Erreur lors du chargement du monde : {e}{RESET}")
        if player:
            invoke(player.enable, delay=0.1)

def is_night():
    return 1.2 <= (game_time % 2) <= 1.8

def update_lighting():
    time_of_day = game_time % 2
    if time_of_day < 0.5:
        intensity = 0.6 + time_of_day * 0.8
        window.color = color.rgb(150, 220, 255)
    elif time_of_day < 1:
        intensity = 1.0
        window.color = color.rgb(135, 206, 250)
    elif time_of_day < 1.5:
        intensity = 1.0 - (time_of_day - 1) * 1.6
        window.color = color.rgb(100 + intensity * 50, 100 + intensity * 120, 180 + intensity * 75)
    else:
        intensity = 0.2
        window.color = color.rgb(20, 20, 40)
    if ambient_light:
        ambient_light.color = color.rgb(intensity * 150, intensity * 150, intensity * 150)

door_cooldown = 0.0
bed_cooldown = 0.0
tnt_cooldown = 0.0

def update():
    global current_texture, current_texture_index, door_cooldown, current_door_rotation, current_bed_rotation, bed_cooldown, tnt_cooldown, game_time
    game_time += time.dt / day_duration
    update_lighting()
    if door_cooldown > 0:
        door_cooldown -= time.dt
    if bed_cooldown > 0:
        bed_cooldown -= time.dt
    if tnt_cooldown > 0:
        tnt_cooldown -= time.dt
        
    if held_keys['tab']:
        current_texture_index = (current_texture_index + 1) % len(TEXTURE_LIST)
        current_texture = TEXTURES[TEXTURE_LIST[current_texture_index][0]]
        texture_name = TEXTURE_LIST[current_texture_index][1]
        print(f"{BG_LIGHTBLUE}{BLACK}Outil sélectionné : {texture_name}{RESET}")
        time.sleep(0.2)
    
    # Sélection rapide des blocs
    for i in range(10):
        key = str(i) if i != 0 else '0'
        if held_keys[key]:
            if i < len(TEXTURE_LIST):
                current_texture_index = i
                current_texture = TEXTURES[TEXTURE_LIST[current_texture_index][0]]
                print(f"{BG_LIGHTBLUE}{BLACK}Outil sélectionné : {TEXTURE_LIST[current_texture_index][1]}{RESET}")
                time.sleep(0.1)
    
    if held_keys['6']:
        if current_texture != TEXTURES['door_tool']:
            current_texture = TEXTURES['door_tool']
            print(f"{BG_LIGHTBLUE}{BLACK}Outil sélectionné : Porte (Rotation actuelle : {current_door_rotation} degrés){RESET}")
            time.sleep(0.1)
    elif held_keys['-']:
        if current_texture != TEXTURES['bed_tool']:
            current_texture = TEXTURES['bed_tool']
            print(f"{BG_LIGHTBLUE}{BLACK}Outil sélectionné : Lit (Rotation actuelle : {current_bed_rotation} degrés){RESET}")
            time.sleep(0.1)
    elif held_keys['=']:
        if current_texture != TEXTURES['tnt_tool']:
            current_texture = TEXTURES['tnt_tool']
            print(f"{BG_LIGHTBLUE}{BLACK}Outil sélectionné : TNT{RESET}")
            time.sleep(0.1)

    if held_keys['e']:
        if door_cooldown <= 0 or bed_cooldown <= 0 or tnt_cooldown <= 0:
            entities_to_check = list(world_entities)
            for entity in entities_to_check:
                if not entity.enabled:
                    continue
                if isinstance(entity, Door) and door_cooldown <= 0:
                    distance_to_door = distance(player.position, entity.position)
                    if distance_to_door < 3:
                        entity.toggle_door()
                        door_cooldown = 1.0
                        break
                elif isinstance(entity, Bed) and bed_cooldown <= 0:
                    distance_to_bed = distance(player.position, entity.position)
                    if distance_to_bed < 2:
                        entity.interact()
                        bed_cooldown = 2.0
                        break
                elif isinstance(entity, TNTBlock) and tnt_cooldown <= 0:
                    distance_to_tnt = distance(player.position, entity.position)
                    if distance_to_tnt < 3:
                        entity.prime(delay=5)
                        tnt_cooldown = 2.0
                        break
    
    # Mettre à jour les mobs
    entities_to_update = list(world_entities)
    for entity in entities_to_update:
        if hasattr(entity, 'update') and isinstance(entity, (Dog, Sheep, Blockyman, Chicken)):
            if entity.enabled:
                entity.update()

def input(key):
    if key == 'f':
        save_world("my_world.scw")
    elif key == 'l':
        try:
            from tkinter import filedialog
            save_path = filedialog.asksaveasfilename(
                initialdir=".", title="Sauvegarder le monde sous...",
                defaultextension=".scw", filetypes=(("Fichiers Stro Craft World", "*.scw"), ("Tous les fichiers", "*.*"))
            )
            if save_path:
                save_world(save_path)
        except ImportError:
            print(f"{RED}tkinter non disponible. Utilisez la touche 'f' pour sauvegarder.{RESET}")
    elif key == 'escape':
        application.quit()
    elif key == 't':
        global game_time
        game_time += 0.5
        print(f"{CYAN}Temps modifié à : {game_time % 2} (nuit : {is_night()}){RESET}")

def create_initial_world():
    """Crée la surface du monde et génère les entités de base, y compris les animaux."""
    global player_inventory
    
    print(f"{BG_LIGHTBLUE}{BLACK}Création du monde initial (35x35)...{RESET}")
    for z in range(40):
        for x in range(40):
            # Couche supérieure : herbe
            block_grass = Block(position=(x, 0, z), texture=TEXTURES['grass'])
            world_entities.append(block_grass)
            # Couche intermédiaire : terre
            block_dirt = Block(position=(x, -1, z), texture=TEXTURES['dirt'])
            world_entities.append(block_dirt)
            # Couche inférieure : bedrock (à partir de y = -2)
            for y in range(-2, -10):
                block_bedrock = Block(position=(x, y, z), texture=TEXTURES['bedrock'])
                world_entities.append(block_bedrock)
    print(f"{BG_LIGHTBLUE}{BLACK}Monde initial créé avec {len(world_entities)} blocs.{RESET}")
    print(f"{BG_LIGHTBLUE}{BLACK}Génération de quelques animaux et Blockyman...{RESET}")
    
    # Ajouter quelques arbres
    for _ in range(5):
        tree_pos = (random.randint(3, 31), 0, random.randint(3, 31))
        tree = Tree(position=tree_pos)
    
    # Générer des animaux
    for _ in range(2):  # 2 chiens
        # La position des chiens est déjà gérée par une classe, mais peut nécessiter une vérification similaire
        spawn_pos = (random.randint(5, 30), 1, random.randint(5, 30))
        dog = Dog(position=spawn_pos)
        world_entities.append(dog)
        
    for _ in range(3):  # 3 moutons
        # Correction pour placer les moutons sur le sol
        random_x = random.randint(5, 30)
        random_z = random.randint(5, 30)
        
        # Lance un rayon depuis le haut pour trouver le sol (le Y=10 est arbitrairement haut)
        hit_info = raycast(Vec3(random_x, 10, random_z), Vec3(0, -1, 0))
        
        if hit_info.hit:
            # Place le mouton sur le sol détecté par le lancer de rayon
            # On ajoute un petit décalage (0.1) pour éviter que le mouton ne soit dans le sol
            spawn_pos = (random_x, hit_info.point.y + 0.1, random_z)
            sheep = Sheep(position=spawn_pos)
            world_entities.append(sheep)
            print(f"{GREEN}Mouton généré à {spawn_pos} sur le sol.{RESET}")
        else:
            print(f"{RED}Impossible de trouver le sol pour le mouton à {random_x}, {random_z}. Il sera ignoré.{RESET}")
        
    for _ in range(4):  # 4 poulets
        spawn_pos = (random.randint(5, 30), 1, random.randint(5, 30))
        chicken = Chicken(position=spawn_pos)
        world_entities.append(chicken)
        
    for _ in range(3):  # 3 Blockyman
        spawn_pos = (random.randint(5, 30), 1, random.randint(5, 30))
        blockyman = Blockyman(position=spawn_pos)
        world_entities.append(blockyman)
    
    # Donner des objets de départ au joueur (inventaire en arrière-plan
    # Donner des objets de départ au joueur
    add_to_inventory('wood', 10)
    add_to_inventory('stone', 5)
    add_to_inventory('crafting_table', 1)
    
    print(f"{BG_LIGHTBLUE}{BLACK}Animaux et créatures générés.{RESET}")
    print(f"{CYAN}Objets de départ ajoutés à l'inventaire !{RESET}")
    if player:
        invoke(player.enable, delay=0.1)
def creat_extra_itemes():
 add_to_inventory('red_cube', 1)
 add_to_inventory('white_bloc', 2)
 add_to_inventory('glass', 1)
 add_to_inventory('yellow_cube', 1)
 add_to_inventory('black_cube', 2)
def show_controls():
    print(f"\n{BG_GREEN}{BLACK}=== Commandes du jeu ==={RESET}")
    print(f"{YELLOW}TAB{RESET} - Changer de bloc (cyclique)")
    print(f"{YELLOW}1-9,0{RESET} - Sélection rapide de blocs")
    print(f"{YELLOW}6{RESET} - Outil Porte")
    print(f"{YELLOW}-{RESET} - Outil Lit")
    print(f"{YELLOW}={RESET} - Outil TNT")
    print(f"{YELLOW}E{RESET} - Interagir (portes, lits, TNT, crafting)")
    print(f"{YELLOW}C{RESET} - Ouvrir/fermer inventaire (Tkinter)")
    print(f"{YELLOW}F{RESET} - Sauvegarder le monde")
    print(f"{YELLOW}L{RESET} - Sauvegarder sous...")
    print(f"{YELLOW}T{RESET} - Avancer le temps (pour test)")
    print(f"{YELLOW}ESC{RESET} - Quitter")
    print(f"{CYAN}Cycle jour/nuit automatique activé !{RESET}")
    print(f"{CYAN}Les Blockyman cherchent un lit la nuit !{RESET}")
    print(f"{GREEN}Interface Tkinter pour inventaire et crafting !{RESET}\n")

def setup_game():
    """Initialise l'environnement de jeu Ursina."""
    global player, sleep_fade_overlay, ambient_light
    player = FirstPersonController(y=5, origin_y=-0.5, collider='box', enabled=False)
    mouse.locked = True
    sleep_fade_overlay = Entity(parent=camera.ui, model='quad', color=color.black, scale=(2, 2),
                                position=(0, 0, 1), alpha=0, enabled=True)
    window.fullscreen = False
    window.color = color.rgb(150, 220, 255)
    DirectionalLight(y=2, x=3, z=2, shadows=True)
    ambient_light = AmbientLight(color=color.rgb(150, 150, 150))
    
    if game_action == "load" and game_load_path:
        print(f"{BG_LIGHTBLUE}{BLACK}Chargement du monde depuis : {game_load_path}{RESET}")
        load_world(game_load_path)
    else:
        print(f"{BG_LIGHTBLUE}{BLACK}Création d'un nouveau monde.{RESET}")
        create_initial_world()
        creat_extra_itemes()
    show_controls()
    app.run()

# --- Logique principale : lancer d'abord le menu ---
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Stro Craft Beta - Menu Principal")
    root.geometry("700x500")
    root.resizable(True, True)
    root.configure(bg="#2c3e50")

    title_label = tk.Label(root, text="Stro Craft Beta", font=("Arial", 30, "bold"), fg="#ecf0f1", bg="#2c3e50")
    title_label.pack(pady=30)

    subtitle_label = tk.Label(root, text="Avec interface Tkinter améliorée", font=("Arial", 12), fg="#95a5a6", bg="#2c3e50")
    subtitle_label.pack(pady=(0, 20))

    new_world_button = tk.Button(root, text="🌍 Nouveau Monde", command=start_new_game,
                                 font=("Arial", 14), bg="#27ae60", fg="white",
                                 activebackground="#2ecc71", activeforeground="white",
                                 width=20, height=2, bd=0, relief="flat")
    new_world_button.pack(pady=10)

    import_button = tk.Button(root, text="📁 Importer depuis .scw", command=import_world,
                              font=("Arial", 14), bg="#3498db", fg="white",
                              activebackground="#2980b9", activeforeground="white",
                              width=20, height=2, bd=0, relief="flat")
    import_button.pack(pady=10)

    help_button = tk.Button(root, text="❓ Aide", command=show_help,
                            font=("Arial", 14), bg="#f39c12", fg="white",
                            activebackground="#f1c40f", activeforeground="white",
                            width=20, height=2, bd=0, relief="flat")
    help_button.pack(pady=10)

    settings_button = tk.Button(root, text="ℹ️ À propos du jeu", command=show_settings,
                                font=("Arial", 14), bg="#95a5a6", fg="white",
                                activebackground="#bdc3c7", activeforeground="white",
                                width=20, height=2, bd=0, relief="flat")
    settings_button.pack(pady=10)

    # Footer
    footer_label = tk.Label(root, text="Version Beta avec système Tkinter", 
                           font=("Arial", 10), fg="#7f8c8d", bg="#2c3e50")
    footer_label.pack(side=tk.BOTTOM, pady=10)

    root.mainloop()
